<?php

$app = require_once __DIR__.'/../src/app.php';

$app->run();
